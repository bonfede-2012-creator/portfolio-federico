import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Layout from '@/components/Layout';
import HomePage from '@/pages/HomePage';
import CatalogPage from '@/pages/CatalogPage';
import AboutPage from '@/pages/AboutPage';
import ContactPage from '@/pages/ContactPage';
import CartPage from '@/pages/CartPage';

function App() {
  return (
    <>
      <Helmet>
        <title>Antiplanos Coralinos - Corales y Fauna Marina Premium</title>
        <meta name="description" content="Descubre nuestra selección premium de corales y fauna marina. Calidad excepcional y sostenibilidad garantizada." />
      </Helmet>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<HomePage />} />
          <Route path="catalogo" element={<CatalogPage />} />
          <Route path="nosotros" element={<AboutPage />} />
          <Route path="contacto" element={<ContactPage />} />
          <Route path="carrito" element={<CartPage />} />
        </Route>
      </Routes>
    </>
  );
}

export default App;
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';

function CatalogFilter({ 
  selectedCategory, 
  setSelectedCategory, 
  selectedSubcategory, 
  setSelectedSubcategory 
}) {
  const categories = ['Todos', 'Corales', 'Invertebrados', 'Anemonas', 'Plantas', 'Productos'];
  
  const subcategoriesMap = {
    Corales: ['Blandos', 'LPS', 'SPS'],
    Invertebrados: ['Cangrejos'],
    Anemonas: [],
    Plantas: ['Algas'],
    Productos: ['Piedras', 'Sales'],
    Todos: []
  };

  const currentSubcategories = ['Todos', ...(subcategoriesMap[selectedCategory] || [])];

  return (
    <div className="space-y-6 mb-12">
      {/* Primary Categories */}
      <div className="flex flex-wrap justify-center gap-3">
        {categories.map((category) => (
          <motion.button
            key={category}
            onClick={() => {
              setSelectedCategory(category);
              setSelectedSubcategory('Todos');
            }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`px-6 py-3 rounded-full text-sm font-semibold transition-all duration-300 backdrop-blur-md border ${
              selectedCategory === category
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white border-transparent shadow-lg shadow-cyan-500/30'
                : 'bg-slate-800/40 border-slate-700 text-gray-300 hover:bg-slate-700/60 hover:text-white hover:border-cyan-500/30'
            }`}
          >
            {category}
          </motion.button>
        ))}
      </div>

      {/* Subcategories (Conditional) */}
      <AnimatePresence mode="wait">
        {selectedCategory !== 'Todos' && currentSubcategories.length > 1 && (
          <motion.div
            key={selectedCategory}
            initial={{ opacity: 0, height: 0, y: -10 }}
            animate={{ opacity: 1, height: 'auto', y: 0 }}
            exit={{ opacity: 0, height: 0, y: -10 }}
            className="overflow-hidden"
          >
            <div className="flex flex-wrap justify-center gap-3 pt-2">
              {currentSubcategories.map((sub) => (
                <motion.button
                  key={sub}
                  onClick={() => setSelectedSubcategory(sub)}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`px-5 py-2 rounded-full text-xs font-medium transition-all duration-300 border ${
                    selectedSubcategory === sub
                      ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white border-transparent shadow-md shadow-pink-500/20'
                      : 'bg-slate-800/30 border-slate-700/50 text-gray-400 hover:text-white hover:bg-slate-700/50'
                  }`}
                >
                  {sub}
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default CatalogFilter;
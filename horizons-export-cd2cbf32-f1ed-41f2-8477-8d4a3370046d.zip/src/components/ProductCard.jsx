import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingCart, MessageCircle, ChevronLeft, ChevronRight, Plus, Minus } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { useToast } from '@/hooks/use-toast';
import { WHATSAPP_NUMBER, formatWhatsAppMessage } from '@/constants/config';

function ProductCard({ product }) {
  const { addToCart } = useCart();
  const { toast } = useToast();
  
  // Handle both single image and multiple images
  const productImages = product.images || [product.image];
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const hasMultipleImages = productImages.length > 1;

  // Check if product uses polyp-based pricing
  const isPolypPricing = product.pricingType === 'polyp';
  
  // Polyp quantity state (for polyp-based products)
  const polypRange = product.polypRange || { min: 1, max: 20 };
  const [polypCount, setPolypCount] = useState(polypRange.min);

  // Variant handling
  const hasVariants = product.hasVariants && product.variants && product.variants.length > 0;
  const [selectedVariant, setSelectedVariant] = useState(
    hasVariants ? product.variants[0] : null
  );

  // Get current price and stock based on variant selection or polyp pricing
  const currentPrice = isPolypPricing 
    ? product.polypPrice * polypCount
    : hasVariants 
      ? selectedVariant.price 
      : product.price;
  
  const currentStock = hasVariants ? selectedVariant.stock : product.stock;

  const handleAddToCart = () => {
    if (isPolypPricing) {
      addToCart(product, null, polypCount);
      toast({
        title: '¡Producto añadido!',
        description: `${polypCount} ${polypCount === 1 ? 'pólipo' : 'pólipos'} de ${product.name} añadidos al carrito.`,
      });
    } else if (hasVariants) {
      addToCart(product, selectedVariant);
      toast({
        title: '¡Producto añadido!',
        description: `${product.name} (${selectedVariant.name}) se ha añadido a tu carrito.`,
      });
    } else {
      addToCart(product);
      toast({
        title: '¡Producto añadido!',
        description: `${product.name} se ha añadido a tu carrito.`,
      });
    }
  };

  const handleWhatsApp = () => {
    const message = formatWhatsAppMessage(product, selectedVariant, currentStock, isPolypPricing ? polypCount : null);
    const url = `https://wa.me/${WHATSAPP_NUMBER.replace(/\+/g, '')}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  const goToPrevious = (e) => {
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev === 0 ? productImages.length - 1 : prev - 1));
  };

  const goToNext = (e) => {
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev === productImages.length - 1 ? 0 : prev + 1));
  };

  const goToImage = (index) => {
    setCurrentImageIndex(index);
  };

  const incrementPolyps = () => {
    setPolypCount(prev => Math.min(prev + 1, polypRange.max));
  };

  const decrementPolyps = () => {
    setPolypCount(prev => Math.max(prev - 1, polypRange.min));
  };

  const handlePolypInputChange = (e) => {
    const value = parseInt(e.target.value);
    if (!isNaN(value)) {
      setPolypCount(Math.max(polypRange.min, Math.min(value, polypRange.max)));
    }
  };

  return (
    <motion.div
      whileHover={{ y: -8 }}
      className="group relative flex flex-col h-full bg-slate-800/30 backdrop-blur-md rounded-xl overflow-hidden shadow-lg hover:shadow-2xl hover:shadow-cyan-500/10 transition-all duration-300 border border-slate-700/50"
    >
      {/* Product Image Carousel */}
      <div className="relative aspect-square overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.img
            key={currentImageIndex}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            whileHover={{ scale: 1.1 }}
            src={productImages[currentImageIndex]}
            alt={`${product.name} - Vista ${currentImageIndex + 1}`}
            className="w-full h-full object-cover"
          />
        </AnimatePresence>

        {/* Overlay Gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent opacity-60 group-hover:opacity-40 transition-opacity duration-300" />
        
        {/* Category Badge */}
        <div className="absolute top-3 right-3 flex flex-col items-end gap-1 z-10">
          <span className="px-3 py-1 bg-slate-900/80 backdrop-blur-sm text-cyan-400 text-xs font-semibold rounded-full border border-cyan-500/20">
            {product.category}
          </span>
          {product.subcategory && (
            <span className="px-3 py-1 bg-slate-900/60 backdrop-blur-sm text-pink-400 text-xs font-semibold rounded-full border border-pink-500/20">
              {product.subcategory}
            </span>
          )}
        </div>

        {/* Out of Stock Badge Overlay */}
        {currentStock === 0 && !isPolypPricing && (
          <div className="absolute top-3 left-3 z-10">
            <span className="px-3 py-1.5 bg-red-600/90 backdrop-blur-sm text-white text-xs font-bold rounded-full border-2 border-red-500 shadow-lg">
              AGOTADO
            </span>
          </div>
        )}

        {/* Navigation Arrows - Only show if multiple images */}
        {hasMultipleImages && (
          <>
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={goToPrevious}
              className="absolute left-2 top-1/2 -translate-y-1/2 z-20 p-1.5 bg-slate-900/80 backdrop-blur-sm text-white rounded-full hover:bg-slate-800 transition-colors opacity-0 group-hover:opacity-100"
              aria-label="Imagen anterior"
            >
              <ChevronLeft className="w-5 h-5" />
            </motion.button>
            
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={goToNext}
              className="absolute right-2 top-1/2 -translate-y-1/2 z-20 p-1.5 bg-slate-900/80 backdrop-blur-sm text-white rounded-full hover:bg-slate-800 transition-colors opacity-0 group-hover:opacity-100"
              aria-label="Imagen siguiente"
            >
              <ChevronRight className="w-5 h-5" />
            </motion.button>
          </>
        )}

        {/* Image Dots Indicator - Only show if multiple images */}
        {hasMultipleImages && (
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5 z-10">
            {productImages.map((_, index) => (
              <button
                key={index}
                onClick={() => goToImage(index)}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  index === currentImageIndex
                    ? 'bg-cyan-400 w-6'
                    : 'bg-white/40 hover:bg-white/60'
                }`}
                aria-label={`Ver imagen ${index + 1}`}
              />
            ))}
          </div>
        )}
      </div>

      {/* Product Details */}
      <div className="flex flex-col flex-grow p-5">
        <div className="mb-4 flex-grow">
          <h3 className="text-lg font-bold text-white mb-2 leading-tight group-hover:text-cyan-400 transition-colors">
            {product.name}
          </h3>
          <p className="text-gray-400 text-sm line-clamp-3 leading-relaxed">
            {product.description}
          </p>
        </div>

        {/* Polyp Pricing Selector */}
        {isPolypPricing && (
          <div className="mb-4 p-4 bg-gradient-to-br from-slate-700/40 to-slate-800/40 rounded-lg border border-slate-600/50 backdrop-blur-sm">
            <label className="block text-xs font-semibold text-gray-300 mb-3">
              Cantidad de pólipos:
            </label>
            <div className="flex items-center gap-3 mb-3">
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                onClick={decrementPolyps}
                disabled={polypCount <= polypRange.min}
                className="p-2 bg-slate-600 hover:bg-slate-500 disabled:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
              >
                <Minus className="w-4 h-4" />
              </motion.button>
              
              <input
                type="number"
                min={polypRange.min}
                max={polypRange.max}
                value={polypCount}
                onChange={handlePolypInputChange}
                className="flex-1 text-center text-white font-bold text-xl bg-slate-800/60 border border-slate-600 rounded-lg py-2 px-3 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
              />
              
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                onClick={incrementPolyps}
                disabled={polypCount >= polypRange.max}
                className="p-2 bg-slate-600 hover:bg-slate-500 disabled:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
              >
                <Plus className="w-4 h-4" />
              </motion.button>
            </div>
            <div className="text-center text-sm bg-slate-800/60 rounded-lg py-2 px-3">
              <div className="text-gray-400 mb-1">
                {polypCount} {polypCount === 1 ? 'pólipo' : 'pólipos'} × ${new Intl.NumberFormat('es-AR').format(product.polypPrice)}
              </div>
              <div className="text-cyan-400 font-bold text-lg">
                = ${new Intl.NumberFormat('es-AR').format(currentPrice)}
              </div>
            </div>
          </div>
        )}

        {/* Variant Selector */}
        {hasVariants && !isPolypPricing && (
          <div className="mb-4">
            <label className="block text-xs font-semibold text-gray-400 mb-2">
              Tamaño:
            </label>
            <div className="grid grid-cols-3 gap-2">
              {product.variants.map((variant) => (
                <motion.button
                  key={variant.id}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setSelectedVariant(variant)}
                  className={`px-3 py-2 rounded-lg text-xs font-semibold transition-all duration-200 ${
                    selectedVariant.id === variant.id
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/30'
                      : 'bg-slate-700/50 text-gray-300 hover:bg-slate-700'
                  }`}
                >
                  {variant.name.replace('Frag ', '').replace('Esqueje ', '')}
                </motion.button>
              ))}
            </div>
          </div>
        )}
        
        <div className="flex items-center justify-between mb-4 pt-2 border-t border-slate-700/50">
          <div className="flex flex-col">
            {isPolypPricing ? (
              <>
                <span className="text-xs text-gray-400 mb-1">Precio por pólipo</span>
                <span className="text-xl font-bold text-white">
                  ${new Intl.NumberFormat('es-AR').format(product.polypPrice)}
                </span>
              </>
            ) : (
              <span className="text-2xl font-bold text-white">
                ${new Intl.NumberFormat('es-AR').format(currentPrice)}
              </span>
            )}
          </div>
          {currentStock !== undefined && !isPolypPricing && (
            <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${
              currentStock > 5 
                ? 'bg-green-500/20 text-green-400' 
                : currentStock > 0 
                  ? 'bg-yellow-500/20 text-yellow-400' 
                  : 'bg-red-500/20 text-red-400'
            }`}>
              {currentStock > 0 ? `Stock: ${currentStock}` : 'Agotado'}
            </span>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3 mt-auto">
          <motion.button
            whileHover={{ scale: isPolypPricing || currentStock > 0 ? 1.02 : 1 }}
            whileTap={{ scale: isPolypPricing || currentStock > 0 ? 0.98 : 1 }}
            onClick={handleAddToCart}
            disabled={!isPolypPricing && currentStock === 0}
            className={`flex-1 flex items-center justify-center gap-2 px-4 py-2.5 text-white text-sm font-semibold rounded-lg shadow-lg transition-all duration-300 ${
              !isPolypPricing && currentStock === 0
                ? 'bg-gray-600 cursor-not-allowed opacity-50'
                : 'bg-gradient-to-r from-cyan-500 to-blue-600 shadow-cyan-500/20 hover:shadow-cyan-500/40'
            }`}
          >
            <ShoppingCart className="w-4 h-4" />
            {!isPolypPricing && currentStock === 0 ? 'Agotado' : 'Agregar'}
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleWhatsApp}
            className="flex items-center justify-center px-4 py-2.5 bg-slate-700 hover:bg-green-600 text-white rounded-lg transition-colors duration-300 group/wa"
            title={!isPolypPricing && currentStock === 0 ? "Consultar disponibilidad por WhatsApp" : "Pedir por WhatsApp"}
          >
            <MessageCircle className="w-4 h-4 group-hover/wa:text-white transition-colors" />
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
}

export default ProductCard;
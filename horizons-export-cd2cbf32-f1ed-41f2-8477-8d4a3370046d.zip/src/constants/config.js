export const WHATSAPP_NUMBER = '+34XXXXXXXXX';

export const formatWhatsAppMessage = (product, variant = null, stock = null, polypCount = null) => {
  const stockStatus = stock !== null && stock === 0 ? ' (Actualmente agotado - consultar disponibilidad)' : '';
  
  // Handle polyp-based pricing
  if (polypCount !== null && product.pricingType === 'polyp') {
    const totalPrice = product.polypPrice * polypCount;
    return `Hola! Me interesa el producto: ${product.name} - ${polypCount} ${polypCount === 1 ? 'pólipo' : 'pólipos'} × $${new Intl.NumberFormat('es-AR').format(product.polypPrice)} = $${new Intl.NumberFormat('es-AR').format(totalPrice)}`;
  }
  
  if (variant) {
    return `Hola! Me interesa el producto: ${product.name} (${variant.name}) - $${new Intl.NumberFormat('es-AR').format(variant.price)}${stockStatus}`;
  }
  return `Hola! Me interesa el producto: ${product.name} - $${new Intl.NumberFormat('es-AR').format(product.price)}${stockStatus}`;
};

export const formatCartWhatsAppMessage = (cart) => {
  const items = cart.map(item => {
    // Handle polyp-based items
    if (item.pricingType === 'polyp' && item.polypCount) {
      const itemTotal = item.price * item.quantity;
      return `• ${item.name} - ${item.polypCount} ${item.polypCount === 1 ? 'pólipo' : 'pólipos'} × $${new Intl.NumberFormat('es-AR').format(item.polypPrice)} = $${new Intl.NumberFormat('es-AR').format(item.price)} x ${item.quantity} = $${new Intl.NumberFormat('es-AR').format(itemTotal)}`;
    }
    
    // Handle variant-based items
    const variantText = item.variant ? ` (${item.variant.name})` : '';
    const itemTotal = item.price * item.quantity;
    return `• ${item.name}${variantText} - $${new Intl.NumberFormat('es-AR').format(item.price)} x ${item.quantity} = $${new Intl.NumberFormat('es-AR').format(itemTotal)}`;
  }).join('\n');
  
  const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  
  return `Hola! Me gustaría hacer el siguiente pedido:\n\n${items}\n\nTotal: $${new Intl.NumberFormat('es-AR').format(total)}`;
};
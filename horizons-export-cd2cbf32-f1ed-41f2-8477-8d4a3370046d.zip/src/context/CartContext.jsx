import React, { createContext, useContext, useState, useEffect } from 'react';

const CartContext = createContext();

export function CartProvider({ children }) {
  const [cart, setCart] = useState(() => {
    const savedCart = localStorage.getItem('cart');
    return savedCart ? JSON.parse(savedCart) : [];
  });

  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cart));
  }, [cart]);

  const addToCart = (product, selectedVariant = null, polypCount = null) => {
    setCart((prevCart) => {
      // Create a unique key for products with variants or polyp pricing
      const itemKey = polypCount !== null
        ? `${product.id}-polyp-${polypCount}`
        : selectedVariant 
          ? `${product.id}-${selectedVariant.id}`
          : `${product.id}`;

      const existingItem = prevCart.find((item) => {
        if (polypCount !== null) {
          return item.id === product.id && item.polypCount === polypCount;
        }
        if (selectedVariant) {
          return item.id === product.id && item.variant?.id === selectedVariant.id;
        }
        return item.id === product.id && !item.variant && !item.polypCount;
      });

      if (existingItem) {
        return prevCart.map((item) => {
          if (polypCount !== null) {
            return item.id === product.id && item.polypCount === polypCount
              ? { ...item, quantity: item.quantity + 1 }
              : item;
          }
          if (selectedVariant) {
            return item.id === product.id && item.variant?.id === selectedVariant.id
              ? { ...item, quantity: item.quantity + 1 }
              : item;
          }
          return item.id === product.id && !item.variant && !item.polypCount
            ? { ...item, quantity: item.quantity + 1 }
            : item;
        });
      }

      const newItem = {
        ...product,
        quantity: 1,
        cartItemKey: itemKey
      };

      // Handle polyp-based pricing
      if (polypCount !== null) {
        newItem.polypCount = polypCount;
        newItem.price = product.polypPrice * polypCount;
        newItem.pricingType = 'polyp';
        newItem.polypPrice = product.polypPrice;
      }

      // Handle variant-based pricing
      if (selectedVariant) {
        newItem.variant = selectedVariant;
        newItem.price = selectedVariant.price;
      }

      return [...prevCart, newItem];
    });
  };

  const removeFromCart = (cartItemKey) => {
    setCart((prevCart) => prevCart.filter((item) => item.cartItemKey !== cartItemKey));
  };

  const updateQuantity = (cartItemKey, quantity) => {
    if (quantity <= 0) {
      removeFromCart(cartItemKey);
      return;
    }
    setCart((prevCart) =>
      prevCart.map((item) =>
        item.cartItemKey === cartItemKey ? { ...item, quantity } : item
      )
    );
  };

  const updatePolypCount = (cartItemKey, newPolypCount, polypPrice) => {
    setCart((prevCart) =>
      prevCart.map((item) => {
        if (item.cartItemKey === cartItemKey) {
          return {
            ...item,
            polypCount: newPolypCount,
            price: polypPrice * newPolypCount
          };
        }
        return item;
      })
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0);
  };

  return (
    <CartContext.Provider
      value={{
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        updatePolypCount,
        clearCart,
        getTotalPrice,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
export const products = [
  {
    id: 1,
    name: 'Capnella sp.',
    category: 'Corales',
    subcategory: 'Blandos',
    description: 'Hermoso ejemplar de coral blando con forma arbórea. Es una especie muy resistente, ideal para dar altura y movimiento al acuario.',
    price: 18500,
    images: [
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/6bdcd3858cf377c40e583c8f05a15554.jpg',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/a81e8aa9f3dc414cbdc647784b52a467.jpg'
    ],
    stock: 5 // Stock quantity - easily editable
  },
  {
    id: 2,
    name: 'Sinularia dura',
    category: 'Corales',
    subcategory: 'Blandos',
    description: 'Es un coral blando del Indo-Pacífico, caracterizado por su estructura firme, lobulada y carnosa, a menudo con forma de hoja de arce o lechuga.',
    images: [
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/0e01f0d8b28667588a118c7a87e52a23.jpg',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/b4fbfa6738f72179301ff3ff85f34d5a.jpg',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/c980cd86ae77629d3fa0bea7568f1723.png'
    ],
    hasVariants: true,
    variants: [
      {
        id: 'pequeño',
        name: 'Frag Pequeño',
        price: 14500,
        stock: 8 // Editable stock
      },
      {
        id: 'mediano',
        name: 'Frag Mediano',
        price: 16500,
        stock: 6 // Editable stock
      },
      {
        id: 'grande',
        name: 'Frag Grande',
        price: 18000,
        stock: 4 // Editable stock
      }
    ]
  },
  {
    id: 3,
    name: 'Sarcophyton Pólipos Cortos',
    category: 'Corales',
    subcategory: 'Blandos',
    description: 'Es uno de los corales para principiantes más populares de los acuarios marinos. Con su característica estructura en forma de seta y sus pólipos que se balancean suavemente, confiere a cualquier acuario de arrecife un aspecto natural y animado.',
    images: [
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/a0fef557e41aa7baef3758ba85d809f0.jpg',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/8de2ff2dfa27546416b16381b1bdcd57.jpg',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/f26387cc02308bc522ee488ba757a902.jpg'
    ],
    hasVariants: true,
    variants: [
      {
        id: 'pequeño',
        name: 'Frag Pequeño',
        price: 25000,
        stock: 10 // Editable stock
      },
      {
        id: 'mediano',
        name: 'Frag Mediano',
        price: 30000,
        stock: 7 // Editable stock
      }
    ]
  },
  {
    id: 4,
    name: 'Sinularia Peluda Mollis',
    category: 'Corales',
    subcategory: 'Blandos',
    description: 'Es un coral blando de cuero muy popular y resistente, ideal para acuarios marinos.',
    images: [
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/8f60f54a92ceb0e25121e0013ace0f82.jpg',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/f51f0002714065dd7e1aa67c7de36250.jpg',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/1c9e2d6c366b9128e79a9fdf56b59683.png'
    ],
    hasVariants: true,
    variants: [
      {
        id: 'pequeño',
        name: 'Esqueje Pequeño',
        price: 17500,
        stock: 6 // Editable stock
      }
    ]
  },
  {
    id: 5,
    name: 'Árbol de Kenia',
    category: 'Corales',
    subcategory: 'Blandos',
    description: 'Es un coral blando marino muy popular, resistente y de rápido crecimiento, ideal para principiantes.',
    images: [
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/a36817202f7671f9206acd1ab049d8d4.jpg',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/c805d6b1ff531a1370496c95eec1edae.webp',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/60448f335e1485ab0ebf0fc64830372c.png'
    ],
    hasVariants: true,
    variants: [
      {
        id: 'pequeño',
        name: 'Esqueje Pequeño',
        price: 20000,
        stock: 0 // Out of stock - editable
      }
    ]
  },
  {
    id: 6,
    name: 'Pachyclavularia Viridis',
    category: 'Corales',
    subcategory: 'Blandos',
    description: 'Es un coral blando incrustante, muy popular en acuarofilia, caracterizado por sus pólipos retráctiles con forma de estrella y color verde fluorescente intenso.',
    images: [
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/c3580fe069f8b6a651eda648ea6386a3.png',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/5c2e4fbd186d058b9aab683626b6d56d.jpg',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/7bbc83f05c61a54c87a521f856a8c121.jpg'
    ],
    hasVariants: true,
    variants: [
      {
        id: 'pequeño',
        name: 'Frag Pequeño',
        price: 16000,
        stock: 12 // Editable stock
      },
      {
        id: 'mediano',
        name: 'Frag Mediano',
        price: 19000,
        stock: 8 // Editable stock
      }
    ]
  },
  {
    id: 7,
    name: 'Briareum',
    category: 'Corales',
    subcategory: 'Blandos',
    description: 'Es un género de corales blandos (orden Alcyonacea) muy popular en acuarios marinos, conocidos comúnmente como \'pólipos de estrella\' o \'dedo de corcho\'. Son valorados por su rápido crecimiento, color (a menudo verde o marrón) y facilidad de cuidado.',
    images: [
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/3543410f397a49cf70c19884d6043af4.png',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/c00186ee3cfcd2f317882e8165a1894b.jpg'
    ],
    hasVariants: true,
    variants: [
      {
        id: 'pequeño',
        name: 'Frag Pequeño',
        price: 15000,
        stock: 10 // Editable stock
      }
    ]
  },
  {
    id: 8,
    name: 'Anthelia',
    category: 'Corales',
    subcategory: 'Blandos',
    description: 'Anthelia es un género de corales blandos de la familia Xeniidae, caracterizado por pólipos largos y monomórficos que crecen sobre una base incrustante común.',
    images: [
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/fae3b74c4ba00d9a4d1a029ebc3ae50f.jpg',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/d01d2eca8f632f8d3668f0caca3238fb.jpg',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/bdb1e1ccddcdb5748c8213df9c58af8f.jpg'
    ],
    hasVariants: true,
    variants: [
      {
        id: 'pequeño',
        name: 'Frag Pequeño (10 pólipos aprox)',
        price: 15000,
        stock: 8 // Editable stock
      },
      {
        id: 'mediano',
        name: 'Frag Mediano (17 pólipos aprox)',
        price: 17000,
        stock: 5 // Editable stock
      },
      {
        id: 'grande',
        name: 'Frag Grande (25 pólipos aprox)',
        price: 20000,
        stock: 3 // Editable stock
      }
    ]
  },
  {
    id: 9,
    name: 'Xenia Pulsante',
    category: 'Corales',
    subcategory: 'Blandos',
    description: 'Es un coral blando marino muy popular, caracterizado por el movimiento autónomo y rítmico de contracción y expansión de sus pólipos.',
    images: [
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/afe617ea519118d160452b37829f37cc.jpg',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/8f5505bdeab974170a3f7b22bbb21c0c.jpg',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/b48d2c5464fbed91717588945f97fe67.jpg'
    ],
    hasVariants: true,
    variants: [
      {
        id: 'pequeño',
        name: 'Frag Pequeño',
        price: 20000,
        stock: 10 // Editable stock
      }
    ]
  },
  {
    id: 10,
    name: 'Palythoas',
    category: 'Corales',
    subcategory: 'Blandos',
    description: 'Son anémonas coloniales incrustantes, resistentes y de fácil mantenimiento, muy populares en acuarios marinos por su aspecto acolchado y colores vibrantes.',
    images: [
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/a3462c086d0fca7f9a609eb1d67bf6fe.png',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/5d185f06d6f509aaad4bcb18fdca4bc2.png',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/6137877e6534d3183a5f0552f41ba3bf.png'
    ],
    hasVariants: true,
    variants: [
      {
        id: 'pequeño',
        name: 'Frag Pequeño (7-8 pólipos)',
        price: 14000,
        stock: 8 // Editable stock
      },
      {
        id: 'mediano',
        name: 'Frag Mediano (10-11 pólipos)',
        price: 16000,
        stock: 6 // Editable stock
      }
    ]
  },
  {
    id: 11,
    name: 'Zoanthus Punk Rocker',
    category: 'Corales',
    subcategory: 'Blandos',
    description: 'Es un coral blando colonial destacado por su vibrante centro naranja/rojo contrastado con un anillo verde brillante y faldas largas.',
    price: 3500,
    images: [
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/16dcfb730f062f23bf02cdac0594c7a5.jpg',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/da3903a4fb9c9ff4f0179e89693c2794.webp',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/94be98ea12f24f690539538687f6287f.jpg'
    ],
    stock: 15,
    pricingType: 'polyp',
    polypPrice: 3500
  },
  {
    id: 12,
    name: 'Zoanthus Sonic Flare',
    category: 'Corales',
    subcategory: 'Blandos',
    description: 'Es un coral blando colonial de colores intensos, caracterizado por un centro brillante (amarillo/rosa) y un borde exterior con anillos oxidados o verdosos.',
    price: 9500,
    images: [
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/be785bcae3337a0f3646688115b41e4d.webp',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/4654b637eaa7afa9c4d752db2b3bde17.jpg',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/c18b098b2b8c04c7aa6387b5389408a4.jpg'
    ],
    stock: 50,
    pricingType: 'polyp',
    polypPrice: 9500
  },
  {
    id: 13,
    name: 'Zoanthus Rasta',
    category: 'Corales',
    subcategory: 'Blandos',
    description: 'Es un coral blando colonial muy apreciado por sus vibrantes colores verde neón, naranja y centro oscuro, formando patrones intensos.',
    price: 8500,
    images: [
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/66e286fe92c66c5b0ecd39664c40efa3.webp',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/39777a0a3a04d72dc5f878a8fecb5e77.jpg',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/118a252e23c927c7234af5ea9ff990b3.jpg'
    ],
    stock: 30,
    pricingType: 'polyp',
    polypPrice: 8500,
    polypRange: { min: 1, max: 20 }
  },
  {
    id: 14,
    name: 'Zoanthus Sunny D',
    category: 'Corales',
    subcategory: 'Blandos',
    description: 'En general poseen pequeños pólipos que se alimentan de compuestos orgánicos en disolución, bacterias, algas y detritos, pero la mayoría son fotosintéticos.',
    price: 9000,
    images: [
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/39d2bdcfe49c13d5aad20452c5b5ff9a.webp',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/631a8aac949cf9581f09987c73be7364.jpg',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/d23455bfe8ddb446854bf025fb48594d.jpg'
    ],
    stock: 50,
    pricingType: 'polyp',
    polypPrice: 9000,
    polypRange: { min: 1, max: 20 }
  },
  {
    id: 15,
    name: 'Zoanthus Magician',
    category: 'Corales',
    subcategory: 'Blandos',
    description: 'Son corales blandos coloniales muy valorados en acuariofilia por su llamativo centro rojo intenso rodeado de un anillo amarillo y pestañas oscuras.',
    price: 18500,
    images: [
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/c6ad74f76d87c47de6be705b1417c0a3.jpg',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/f48e9434b1ebc2cc124465c20f613709.jpg',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/1d2cab9e8239da0b333fd68bc6c2f2cc.jpg'
    ],
    stock: 100,
    pricingType: 'polyp',
    polypPrice: 18500,
    polypRange: { min: 1, max: 20 }
  },
  {
    id: 16,
    name: 'Zoanthus Utter Chaos',
    category: 'Corales',
    subcategory: 'Blandos',
    description: 'Es un coral blando muy popular y llamativo, caracterizado por sus intensos colores naranja neón y púrpura en el centro.',
    price: 12000,
    images: [
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/8475bb3bb6e336a02d1cf3f449b90ac0.webp',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/c16f25fe8aa0c75f4b3e4c032ee99c64.jpg',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/c7a9baa21623eb0d022d94ab913dfee6.webp'
    ],
    stock: 50,
    pricingType: 'polyp',
    polypPrice: 12000,
    polypRange: { min: 1, max: 20 }
  },
  {
    id: 17,
    name: 'Zoanthus Fruit Loops',
    category: 'Corales',
    subcategory: 'Blandos',
    description: 'Son corales blandos muy valorados por sus intensos colores, que combinan un centro verde/azul con pestañas de color naranja vibrante.',
    price: 12000,
    images: [
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/fbdba0bf08d4936f273baaea55913b2c.webp',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/023e0cc09cae7abc9582f2990dcd5e26.webp',
      'https://horizons-cdn.hostinger.com/cd2cbf32-f1ed-41f2-8477-8d4a3370046d/c2cf7831768c1a26a4332526c2fbbc5b.jpg'
    ],
    stock: 50,
    pricingType: 'polyp',
    polypPrice: 12000,
    minPolyps: 1,
    maxPolyps: 20
  }
];
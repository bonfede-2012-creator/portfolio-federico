import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Heart, Leaf, Award, Users } from 'lucide-react';

function AboutPage() {
  const values = [
    {
      icon: Heart,
      title: 'Pasión por los Océanos',
      description: 'Dedicados a compartir la belleza del mundo marino con cada acuarista.',
    },
    {
      icon: Leaf,
      title: 'Sostenibilidad',
      description: 'Comprometidos con prácticas responsables y la conservación marina.',
    },
    {
      icon: Award,
      title: 'Calidad Premium',
      description: 'Seleccionamos solo los mejores especímenes con estándares excepcionales.',
    },
    {
      icon: Users,
      title: 'Comunidad',
      description: 'Construimos una familia de apasionados por la acuariofilia marina.',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Nosotros - Antiplanos Coralinos</title>
        <meta name="description" content="Conoce la historia y valores de Antiplanos Coralinos, especialistas en corales y fauna marina premium." />
      </Helmet>

      <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-950">
        {/* Hero Section */}
        <section className="relative pt-28 pb-16 overflow-hidden">
          <div className="absolute inset-0 opacity-20">
            <img
              src="https://images.unsplash.com/photo-1677148435742-0944b14dc134?w=1920&q=80"
              alt="Ocean"
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="relative container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-4xl mx-auto text-center"
            >
              <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
                Sobre <span className="bg-gradient-to-r from-cyan-400 to-pink-500 text-transparent bg-clip-text">Nosotros</span>
              </h1>
              <p className="text-xl text-gray-300 leading-relaxed">
                En Antiplanos Coralinos, compartimos tu pasión por el mundo marino y nos dedicamos a ofrecer los mejores corales y fauna marina con un compromiso inquebrantable con la calidad y la sostenibilidad.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Mission Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
              >
                <h2 className="text-4xl font-bold text-white mb-6">Nuestra Misión</h2>
                <p className="text-gray-300 text-lg leading-relaxed mb-4">
                  Aspiramos a ser el referente en la distribución de corales y fauna marina premium, ofreciendo productos de la más alta calidad mientras promovemos prácticas sostenibles que protejan nuestros océanos.
                </p>
                <p className="text-gray-300 text-lg leading-relaxed">
                  Cada coral que ofrecemos es cuidadosamente seleccionado y cultivado con respeto al medio ambiente, garantizando no solo la belleza de tu acuario, sino también la preservación de los ecosistemas marinos.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="relative rounded-2xl overflow-hidden shadow-2xl"
              >
                <img
                  src="https://images.unsplash.com/photo-1677148435742-0944b14dc134?w=800&q=80"
                  alt="Marine Life"
                  className="w-full h-96 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-cyan-500/30 to-transparent"></div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="py-16 bg-slate-950/50">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="text-4xl font-bold text-white mb-4">Nuestros Valores</h2>
              <p className="text-gray-400 text-lg">Lo que nos define y nos impulsa cada día</p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {values.map((value, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ y: -8 }}
                  className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50 text-center"
                >
                  <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                    <value.icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">{value.title}</h3>
                  <p className="text-gray-400">{value.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Sustainability Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="max-w-4xl mx-auto bg-gradient-to-r from-cyan-500/10 to-blue-600/10 rounded-2xl p-8 md:p-12 border border-cyan-500/20"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6 text-center">
                Compromiso con la <span className="bg-gradient-to-r from-cyan-400 to-pink-500 text-transparent bg-clip-text">Sostenibilidad</span>
              </h2>
              <p className="text-gray-300 text-lg leading-relaxed text-center mb-6">
                Trabajamos exclusivamente con proveedores certificados que practican el cultivo responsable de corales. Cada compra contribuye a programas de conservación marina y restauración de arrecifes.
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <div className="px-6 py-3 bg-slate-800/50 rounded-full border border-cyan-500/30">
                  <span className="text-cyan-400 font-semibold">100% Cultivo Sostenible</span>
                </div>
                <div className="px-6 py-3 bg-slate-800/50 rounded-full border border-cyan-500/30">
                  <span className="text-cyan-400 font-semibold">Certificación Ecológica</span>
                </div>
                <div className="px-6 py-3 bg-slate-800/50 rounded-full border border-cyan-500/30">
                  <span className="text-cyan-400 font-semibold">Preservación Marina</span>
                </div>
              </div>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
}

export default AboutPage;
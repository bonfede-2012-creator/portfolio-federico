import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Minus, Plus, Trash2, ShoppingBag, ArrowLeft, MessageCircle } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { useToast } from '@/hooks/use-toast';
import { WHATSAPP_NUMBER, formatCartWhatsAppMessage } from '@/constants/config';

function CartPage() {
  const { cart, updateQuantity, updatePolypCount, removeFromCart, getTotalPrice } = useCart();
  const { toast } = useToast();

  const handleCheckout = () => {
    toast({
      title: '🚧 Función en desarrollo',
      description: 'El proceso de pago estará disponible próximamente. ¡Gracias por tu paciencia!',
    });
  };

  const handleWhatsAppOrder = () => {
    const message = formatCartWhatsAppMessage(cart);
    const url = `https://wa.me/${WHATSAPP_NUMBER.replace(/\+/g, '')}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  const subtotal = getTotalPrice();
  const shipping = subtotal > 0 ? 2500 : 0; // Shipping in ARS
  const total = subtotal + shipping;

  if (cart.length === 0) {
    return (
      <>
        <Helmet>
          <title>Carrito - Antiplanos Coralinos</title>
          <meta name="description" content="Tu carrito de compras en Antiplanos Coralinos" />
        </Helmet>

        <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-950 pt-28 pb-16">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-2xl mx-auto text-center"
            >
              <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-slate-800 flex items-center justify-center">
                <ShoppingBag className="w-12 h-12 text-gray-500" />
              </div>
              <h1 className="text-3xl font-bold text-white mb-4">Tu carrito está vacío</h1>
              <p className="text-gray-400 mb-8">¡Explora nuestro catálogo y encuentra productos increíbles!</p>
              <Link
                to="/catalogo"
                className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold rounded-full hover:shadow-lg hover:shadow-cyan-500/50 transition-all duration-300"
              >
                <ArrowLeft className="w-4 h-4" />
                Ir al Catálogo
              </Link>
            </motion.div>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>Carrito - Antiplanos Coralinos</title>
        <meta name="description" content="Revisa tu carrito de compras" />
      </Helmet>

      <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-950 pt-28 pb-16">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <h1 className="text-4xl font-bold text-white mb-2">Tu Carrito</h1>
            <p className="text-gray-400">Tienes {cart.length} {cart.length === 1 ? 'producto' : 'productos'} en tu carrito</p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              {cart.map((item, index) => {
                const displayImage = item.images?.[0] || item.image;
                const isPolypProduct = item.pricingType === 'polyp';
                
                return (
                  <motion.div
                    key={item.cartItemKey}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-4 border border-slate-700/50 flex gap-4"
                  >
                    <img
                      src={displayImage}
                      alt={item.name}
                      className="w-24 h-24 rounded-lg object-cover"
                    />
                    
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-white mb-1">{item.name}</h3>
                      {isPolypProduct ? (
                        <span className="inline-block px-2 py-0.5 bg-purple-500/20 text-purple-400 text-xs font-semibold rounded-full mb-2">
                          {item.polypCount} {item.polypCount === 1 ? 'pólipo' : 'pólipos'}
                        </span>
                      ) : item.variant && (
                        <span className="inline-block px-2 py-0.5 bg-cyan-500/20 text-cyan-400 text-xs font-semibold rounded-full mb-2">
                          {item.variant.name}
                        </span>
                      )}
                      
                      {/* Price Display */}
                      <div className="mb-3">
                        {isPolypProduct ? (
                          <div className="flex flex-col">
                            <span className="text-xs text-gray-400">
                              {item.polypCount} × ${new Intl.NumberFormat('es-AR').format(item.polypPrice)}
                            </span>
                            <span className="text-cyan-400 font-bold">
                              = ${new Intl.NumberFormat('es-AR').format(item.price)}
                            </span>
                          </div>
                        ) : (
                          <p className="text-cyan-400 font-bold">
                            ${new Intl.NumberFormat('es-AR').format(item.price)}
                          </p>
                        )}
                      </div>
                      
                      {/* Polyp Count Editor for polyp products */}
                      {isPolypProduct && (
                        <div className="mb-3">
                          <label className="text-xs text-gray-400 mb-1 block">Editar pólipos:</label>
                          <div className="flex items-center gap-2 bg-slate-700/50 rounded-lg w-fit">
                            <button
                              onClick={() => {
                                const newCount = Math.max(1, item.polypCount - 1);
                                updatePolypCount(item.cartItemKey, newCount, item.polypPrice);
                              }}
                              className="p-2 hover:bg-slate-600 rounded-lg transition-colors"
                            >
                              <Minus className="w-3 h-3 text-white" />
                            </button>
                            <span className="text-white font-semibold w-8 text-center text-sm">{item.polypCount}</span>
                            <button
                              onClick={() => {
                                const newCount = Math.min(20, item.polypCount + 1);
                                updatePolypCount(item.cartItemKey, newCount, item.polypPrice);
                              }}
                              className="p-2 hover:bg-slate-600 rounded-lg transition-colors"
                            >
                              <Plus className="w-3 h-3 text-white" />
                            </button>
                          </div>
                        </div>
                      )}
                      
                      {/* Quantity controls */}
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2 bg-slate-700 rounded-lg">
                          <button
                            onClick={() => updateQuantity(item.cartItemKey, item.quantity - 1)}
                            className="p-2 hover:bg-slate-600 rounded-lg transition-colors"
                          >
                            <Minus className="w-4 h-4 text-white" />
                          </button>
                          <span className="text-white font-semibold w-8 text-center">{item.quantity}</span>
                          <button
                            onClick={() => updateQuantity(item.cartItemKey, item.quantity + 1)}
                            className="p-2 hover:bg-slate-600 rounded-lg transition-colors"
                          >
                            <Plus className="w-4 h-4 text-white" />
                          </button>
                        </div>
                        
                        <button
                          onClick={() => removeFromCart(item.cartItemKey)}
                          className="p-2 text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <p className="text-xl font-bold text-white">
                        ${new Intl.NumberFormat('es-AR').format(item.price * item.quantity)}
                      </p>
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {/* Order Summary */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="lg:col-span-1"
            >
              <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50 sticky top-28">
                <h2 className="text-2xl font-bold text-white mb-6">Resumen del Pedido</h2>
                
                <div className="space-y-4 mb-6">
                  <div className="flex justify-between text-gray-300">
                    <span>Subtotal</span>
                    <span className="font-semibold">
                      ${new Intl.NumberFormat('es-AR').format(subtotal)}
                    </span>
                  </div>
                  <div className="flex justify-between text-gray-300">
                    <span>Envío estimado</span>
                    <span className="font-semibold">
                      ${new Intl.NumberFormat('es-AR').format(shipping)}
                    </span>
                  </div>
                  <div className="border-t border-slate-700 pt-4">
                    <div className="flex justify-between text-white text-xl font-bold">
                      <span>Total</span>
                      <span className="bg-gradient-to-r from-cyan-400 to-pink-500 text-transparent bg-clip-text">
                        ${new Intl.NumberFormat('es-AR').format(total)}
                      </span>
                    </div>
                  </div>
                </div>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleCheckout}
                  className="w-full py-4 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all duration-300 mb-3"
                >
                  Proceder al Pago
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleWhatsAppOrder}
                  className="w-full flex items-center justify-center gap-2 py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg transition-all duration-300 mb-3"
                >
                  <MessageCircle className="w-5 h-5" />
                  Pedir por WhatsApp
                </motion.button>

                <Link
                  to="/catalogo"
                  className="block w-full py-3 text-center text-cyan-400 border border-cyan-400 rounded-lg hover:bg-cyan-400 hover:text-white transition-all duration-300"
                >
                  Continuar Comprando
                </Link>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
}

export default CartPage;
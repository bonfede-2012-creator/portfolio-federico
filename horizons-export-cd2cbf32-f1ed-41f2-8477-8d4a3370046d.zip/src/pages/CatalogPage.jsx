import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { FilterX, X } from 'lucide-react';
import { products } from '@/data/products';
import ProductCard from '@/components/ProductCard';
import CatalogFilter from '@/components/CatalogFilter';

function CatalogPage() {
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [selectedSubcategory, setSelectedSubcategory] = useState('Todos');
  const [filteredProducts, setFilteredProducts] = useState(products);

  useEffect(() => {
    let result = products;

    // Filter by main category
    if (selectedCategory !== 'Todos') {
      result = result.filter((p) => p.category === selectedCategory);
    }

    // Filter by subcategory (Generic for all categories that have subcategories)
    if (selectedSubcategory !== 'Todos') {
      result = result.filter((p) => p.subcategory === selectedSubcategory);
    }

    setFilteredProducts(result);
  }, [selectedCategory, selectedSubcategory]);

  const clearFilters = () => {
    setSelectedCategory('Todos');
    setSelectedSubcategory('Todos');
  };

  const getCategoryDescription = () => {
    switch (selectedCategory) {
      case 'Corales':
        return 'Descubre nuestra colección de corales vivos, desde blandos fáciles de cuidar hasta exigentes SPS para expertos.';
      case 'Anemonas':
        return 'Anémonas espectaculares que servirán de hogar a tus peces payaso y darán movimiento a tu acuario.';
      case 'Invertebrados':
        return 'Cangrejos especializados en limpieza y mantenimiento de tu ecosistema marino.';
      case 'Plantas':
        return 'Macroalgas beneficiosas para la filtración natural y la estética de tu refugio o acuario principal.';
      case 'Productos':
        return 'Todo lo necesario para el hardscape y la química del agua: sales premium y rocas para aquascaping.';
      default:
        return 'Explora nuestro catálogo completo de vida marina premium y suministros especializados.';
    }
  };

  return (
    <>
      <Helmet>
        <title>Catálogo - Antiplanos Coralinos</title>
        <meta name="description" content="Explora nuestro catálogo completo de corales, invertebrados y productos marinos." />
      </Helmet>

      <div className="min-h-screen bg-slate-900 pt-28 pb-16 relative">
        {/* Background Gradients */}
        <div className="fixed inset-0 pointer-events-none">
          <div className="absolute top-0 left-0 w-full h-[500px] bg-gradient-to-b from-cyan-900/20 to-transparent" />
          <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-blue-900/10 rounded-full blur-3xl" />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          {/* Header Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-10"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Nuestro <span className="bg-gradient-to-r from-cyan-400 to-pink-500 text-transparent bg-clip-text">Catálogo</span>
            </h1>
            <p className="text-gray-300 text-lg max-w-2xl mx-auto leading-relaxed">
              {getCategoryDescription()}
            </p>
          </motion.div>

          {/* Filter Component */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <CatalogFilter
              selectedCategory={selectedCategory}
              setSelectedCategory={setSelectedCategory}
              selectedSubcategory={selectedSubcategory}
              setSelectedSubcategory={setSelectedSubcategory}
            />
          </motion.div>

          {/* Results Info Bar */}
          <motion.div 
            className="flex items-center justify-between mb-8 pb-4 border-b border-slate-800"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <p className="text-gray-400">
              Mostrando <span className="text-white font-bold">{filteredProducts.length}</span> productos
              {(selectedCategory !== 'Todos' || selectedSubcategory !== 'Todos') && (
                <span className="ml-1">
                  en <span className="text-cyan-400">{selectedCategory}</span>
                  {selectedSubcategory !== 'Todos' && (
                    <> / <span className="text-pink-400">{selectedSubcategory}</span></>
                  )}
                </span>
              )}
            </p>
            
            {(selectedCategory !== 'Todos' || selectedSubcategory !== 'Todos') && (
              <button
                onClick={clearFilters}
                className="flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors"
              >
                <X className="w-4 h-4" />
                Limpiar filtros
              </button>
            )}
          </motion.div>

          {/* Products Grid */}
          <motion.div
            layout
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
          >
            <AnimatePresence mode="popLayout">
              {filteredProducts.map((product) => (
                <motion.div
                  key={product.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.3 }}
                >
                  <ProductCard product={product} />
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>

          {/* Empty State */}
          {filteredProducts.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-20"
            >
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-slate-800/50 mb-4">
                <FilterX className="w-8 h-8 text-gray-500" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">No se encontraron productos</h3>
              <p className="text-gray-400">Intenta seleccionar otra categoría o filtro.</p>
              <button
                onClick={clearFilters}
                className="mt-6 px-6 py-2 bg-cyan-500/10 text-cyan-400 rounded-full hover:bg-cyan-500/20 transition-colors"
              >
                Ver todos los productos
              </button>
            </motion.div>
          )}
        </div>
      </div>
    </>
  );
}

export default CatalogPage;